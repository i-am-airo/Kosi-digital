import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import Pricing from "@/components/Pricing";
import Testimonials from "@/components/Testimonials";
import FAQ from "@/components/FAQ";
import Blog from "@/components/Blog";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

/**
 * Kosi Digital - Home Page
 * 
 * Design Philosophy: Premium Minimalism with Trust
 * - Clean, spacious layouts with strategic use of cyan/blue and deep navy (#1E2D35)
 * - Refined typography with bold display font paired with clean body font
 * - Data-driven visuals and metrics to reinforce competitive edge
 * - Confident, direct, results-focused tone
 * 
 * Page Structure:
 * 1. Header - Navigation and branding
 * 2. Hero - Value proposition with strong CTA
 * 3. Services - Visual breakdown of 5 core offerings
 * 4. Pricing - Transparent, tiered packages
 * 5. Testimonials - Real agent success stories
 * 6. FAQ - Common questions and answers
 * 7. Blog - Resources and guides
 * 8. About - Why agents choose Kosi Digital
 * 9. Contact - Lead capture and consultation booking
 * 10. Footer - Links and contact info
 */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      <main>
        <Hero />
        <Services />
        <Pricing />
        <Testimonials />
        <FAQ />
        <Blog />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
