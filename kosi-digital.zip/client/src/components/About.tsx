import { CheckCircle2 } from "lucide-react";

const LOGO_FULL_URL = "/manus-storage/kosi-logo-full-v3_278323a3.png";

export default function About() {
  return (
    <section id="about" className="py-20 md:py-32 bg-gradient-to-b from-white to-gray-50">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h2 className="kosi-section-title">Why Real Estate Agents Choose Kosi Digital</h2>
          <p className="kosi-section-subtitle">
            We combine creative excellence with data-driven strategy
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Logo and Tagline */}
          <div className="flex flex-col items-center lg:items-start">
            <div className="mb-8 w-full max-w-sm">
              <img 
                src={LOGO_FULL_URL} 
                alt="Kosi Digital" 
                className="w-full h-auto"
              />
            </div>
            
            <div className="text-center lg:text-left">
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                We understand the real estate game. After years of working with agents, we realized one thing: most ad agencies don't speak your language.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                That's why we built Kosi Digital. We combine creative excellence with data-driven strategy to deliver ads that actually convert, not just look pretty.
              </p>
            </div>
          </div>

          {/* Right: Key Points */}
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-cyan-100 rounded-lg flex-shrink-0">
                <CheckCircle2 className="text-cyan-600" size={24} />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Data-Driven Strategy</h4>
                <p className="text-muted-foreground">
                  Every creative decision backed by analytics and real estate market insights. We don't guess—we measure and optimize.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-cyan-100 rounded-lg flex-shrink-0">
                <CheckCircle2 className="text-cyan-600" size={24} />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Creative Excellence</h4>
                <p className="text-muted-foreground">
                  Award-winning design and video production that stops scrolls and drives action. Your ads will stand out in the feed.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-cyan-100 rounded-lg flex-shrink-0">
                <CheckCircle2 className="text-cyan-600" size={24} />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Transparent Communication</h4>
                <p className="text-muted-foreground">
                  Clear reporting, regular strategy calls, and honest conversations about ROI. No fluff, just results.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-cyan-100 rounded-lg flex-shrink-0">
                <CheckCircle2 className="text-cyan-600" size={24} />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Dedicated Support</h4>
                <p className="text-muted-foreground">
                  Your own account manager who knows your business and optimizes continuously. We're invested in your success.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
