import { Check } from "lucide-react";

const pricingTiers = [
  {
    id: 1,
    name: "Ad Creative Package",
    description: "For agents who already run ads",
    priceRange: "$150–$250",
    period: "/month",
    features: [
      "4 static ad creatives per month OR 2 video ads per month",
      "Basic copy suggestions",
      "Creative strategy recommendations",
    ],
    cta: "Get Started",
    highlight: false,
  },
  {
    id: 2,
    name: "Lead Generation Starter",
    description: "Your entry-level flagship offer",
    priceRange: "$300–$500",
    period: "/month",
    features: [
      "Meta Ads setup",
      "Campaign management",
      "4 creatives per month",
      "2 video ads per month",
      "Lead form setup",
      "Monthly reporting",
    ],
    cta: "Get Started",
    highlight: false,
  },
  {
    id: 3,
    name: "Growth Lead Generation",
    description: "For agents actively spending on ads",
    priceRange: "$600–$1,000",
    period: "/month",
    features: [
      "Everything in Starter plus:",
      "8 creatives per month",
      "4 video ads per month",
      "Retargeting campaigns",
      "Audience testing",
      "Competitor research",
      "Landing page recommendations",
      "Bi-weekly strategy calls",
    ],
    cta: "Get Started",
    highlight: true,
  },
  {
    id: 4,
    name: "Premium Marketing Partner",
    description: "For top-producing agents and brokerages",
    priceRange: "$1,200–$2,500",
    period: "/month",
    features: [
      "Everything in Growth plus:",
      "CRM integration",
      "Lead tracking system",
      "AI-assisted follow-up setup",
      "Full creative production",
      "Funnel optimization",
      "Weekly strategy sessions",
    ],
    cta: "Get Started",
    highlight: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-20 md:py-32 bg-gray-50">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h2 className="kosi-section-title">Transparent Pricing</h2>
          <p className="kosi-section-subtitle">
            Choose the plan that fits your business stage. Upgrade anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {pricingTiers.map((tier) => (
            <div
              key={tier.id}
              className={`rounded-lg transition-all duration-300 flex flex-col ${
                tier.highlight
                  ? "lg:col-span-1 bg-white border-2 border-cyan-500 shadow-xl ring-2 ring-cyan-500/20"
                  : "bg-white border border-gray-200 shadow-sm hover:shadow-md"
              }`}
            >
              {/* Badge for popular tier */}
              {tier.highlight && (
                <div className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white text-sm font-semibold px-4 py-2 rounded-t-lg text-center">
                  Most Popular
                </div>
              )}

              <div className="p-6 flex flex-col flex-1">
                {/* Tier Name */}
                <h3 className="text-xl font-bold text-foreground mb-1">
                  {tier.name}
                </h3>
                <p className="text-xs text-muted-foreground mb-4">
                  {tier.description}
                </p>

                {/* Price */}
                <div className="mb-6">
                  <div className="text-3xl font-bold text-foreground">
                    {tier.priceRange}
                    <span className="text-sm text-muted-foreground font-normal">
                      {tier.period}
                    </span>
                  </div>
                </div>

                {/* CTA Button */}
                <a
                  href="#contact"
                  className={`w-full py-2.5 px-4 rounded-lg font-semibold transition-all duration-200 text-center block mb-6 text-sm ${
                    tier.highlight
                      ? "kosi-button-primary"
                      : "border-2 border-cyan-500 text-cyan-600 hover:bg-cyan-50"
                  }`}
                >
                  {tier.cta}
                </a>

                {/* Features List */}
                <div className="space-y-2 flex-1">
                  {tier.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <Check className="text-cyan-600 flex-shrink-0 mt-0.5" size={16} />
                      <span className="text-xs leading-snug text-foreground">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Note */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground">
            All plans include 30-day money-back guarantee.{" "}
            <a href="#contact" className="text-cyan-600 font-semibold hover:underline">
              Have questions? Let's talk.
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
