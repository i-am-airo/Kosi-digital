import { ArrowRight } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const blogPosts = [
  {
    id: 1,
    title: "5 Ad Creative Mistakes Real Estate Agents Make (And How to Fix Them)",
    excerpt: "Most real estate ads fail because they focus on the property, not the buyer. Learn the 5 biggest mistakes agents make with their ad creatives and exactly how to fix them to boost lead quality.",
    category: "Ad Strategy",
    readTime: "5 min read",
    slug: "ad-creative-mistakes",
  },
  {
    id: 2,
    title: "How to Calculate Your Ad ROI: A Real Estate Agent's Guide",
    excerpt: "Confused about whether your ads are actually working? This guide walks you through calculating your true ROI, understanding cost-per-lead, and knowing when to scale or pause campaigns.",
    category: "Analytics",
    readTime: "7 min read",
    slug: "calculate-ad-roi",
  },
  {
    id: 3,
    title: "The Complete Guide to Real Estate Video Ads That Convert",
    excerpt: "Video ads get 3x more engagement than static images. Discover what makes a real estate video ad work, common mistakes, and the exact format that generates the most qualified leads.",
    category: "Video Marketing",
    readTime: "8 min read",
    slug: "video-ads-guide",
  },
  {
    id: 4,
    title: "Audience Targeting for Real Estate: Who Should See Your Ads?",
    excerpt: "Showing your ads to the wrong people wastes money. Learn how to build laser-focused audiences based on buyer behavior, location, and intent to maximize your ad spend.",
    category: "Targeting",
    readTime: "6 min read",
    slug: "audience-targeting",
  },
  {
    id: 5,
    title: "Retargeting Campaigns: Turn Website Visitors into Leads",
    excerpt: "Most people who visit your website aren't ready to buy yet. Learn how retargeting works and how to use it to stay top-of-mind and convert interested prospects into qualified leads.",
    category: "Lead Generation",
    readTime: "6 min read",
    slug: "retargeting-campaigns",
  },
  {
    id: 6,
    title: "Landing Pages That Convert: Real Estate Edition",
    excerpt: "A great ad means nothing without a great landing page. Discover the exact elements that make a real estate landing page convert visitors into leads at 20%+ rates.",
    category: "Conversion",
    readTime: "7 min read",
    slug: "landing-pages",
  },
];

export default function Blog() {
  const [email, setEmail] = useState("");
  const subscribeNewsletter = trpc.newsletter.subscribe.useMutation();

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter your email");
      return;
    }

    subscribeNewsletter.mutate(
      { email, source: "blog_newsletter" },
      {
        onSuccess: (result) => {
          if (result.success) {
            toast.success(result.message);
            setEmail("");
          } else {
            toast.error(result.message);
          }
        },
        onError: () => {
          toast.error("Failed to subscribe. Please try again.");
        },
      }
    );
  };

  return (
    <section id="resources" className="py-20 md:py-32 bg-white">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h2 className="kosi-section-title">Resources & Guides</h2>
          <p className="kosi-section-subtitle">
            Learn the strategies and tactics that top-performing real estate agents use to generate consistent leads
          </p>
        </div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {blogPosts.map((post) => (
            <article
              key={post.id}
              className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-lg transition-shadow duration-300 flex flex-col"
            >
              {/* Category & Read Time */}
              <div className="flex items-center justify-between mb-4">
                <span className="inline-block px-3 py-1 bg-cyan-100 text-cyan-700 text-xs font-semibold rounded-full">
                  {post.category}
                </span>
                <span className="text-xs text-muted-foreground">
                  {post.readTime}
                </span>
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-foreground mb-3 leading-snug flex-1">
                {post.title}
              </h3>

              {/* Excerpt */}
              <p className="text-sm text-muted-foreground mb-6 flex-1">
                {post.excerpt}
              </p>

              {/* CTA */}
              <a
                href={`/blog/${post.slug}`}
                className="inline-flex items-center gap-2 text-cyan-600 font-semibold hover:text-cyan-700 transition-colors"
              >
                Read More
                <ArrowRight size={16} />
              </a>
            </article>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16 pt-12 border-t border-gray-200">
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Want more strategies delivered to your inbox? Subscribe to our weekly newsletter for ad tips, case studies, and real estate marketing insights.
          </p>
          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
              disabled={subscribeNewsletter.isPending}
            />
            <button
              type="submit"
              className="kosi-button-primary px-6 py-3 disabled:opacity-50"
              disabled={subscribeNewsletter.isPending}
            >
              {subscribeNewsletter.isPending ? "Subscribing..." : "Subscribe"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
