import { useState } from "react";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    id: 1,
    question: "How long until I see results?",
    answer: "Most campaigns begin generating data and leads within the first few days of launch. However, meaningful optimization typically takes 2–4 weeks as we test audiences, creatives, and campaign settings. Real estate marketing is a process, and the best results come from consistent refinement over time.",
  },
  {
    id: 2,
    question: "Can you work with my existing ad campaigns?",
    answer: "Absolutely. We can audit your current campaigns, identify what's working and what's not, and optimize them immediately. Many of our clients come to us because their existing ads aren't performing. We typically improve cost-per-lead by 30-50% within the first month.",
  },
  {
    id: 3,
    question: "What if I'm not happy with the results?",
    answer: "Client satisfaction is important to me. If you're not satisfied, we'll review the campaign data, discuss your concerns, and make adjustments where needed. There are no long-term contracts, so you can cancel the service if you feel it's not the right fit for your business.",
  },
  {
    id: 4,
    question: "Do you work with teams and brokerages?",
    answer: "Yes. Our Premium Marketing Partner package is specifically designed for teams and brokerages managing multiple agents. We handle creative production, campaign management, and lead tracking for your entire organization. Many brokerages use us to standardize their ad quality across all agents.",
  },
  {
    id: 5,
    question: "What platforms do you advertise on?",
    answer: "We specialize in Meta (Facebook & Instagram) advertising, which is where real estate buyers spend most of their time. We also set up landing pages optimized for lead capture and can integrate with your CRM for seamless lead management.",
  },
  {
    id: 6,
    question: "How do you measure success?",
    answer: "We track everything: cost-per-lead, lead quality, conversion rate, and ultimately, closed deals. You'll get monthly reports showing exactly where your money is going and what results you're getting. With our Premium package, you get real-time lead tracking and bi-weekly strategy calls to discuss performance.",
  },
  {
    id: 7,
    question: "Can I cancel anytime?",
    answer: "Yes. All our packages are month-to-month with no long-term contracts. You can upgrade, downgrade, or cancel anytime. That said, most agents stay with us because the results speak for themselves.",
  },
  {
    id: 8,
    question: "Do you handle lead follow-up?",
    answer: "My primary focus is generating qualified leads through advertising. Lead follow-up is typically handled by you or your team. However, I can help set up lead management systems, CRM integrations, and automation tools to improve your follow-up process.",
  },
];

export default function FAQ() {
  const [openId, setOpenId] = useState<number | null>(null);

  const toggleFAQ = (id: number) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section id="faq" className="py-20 md:py-32 bg-gradient-to-b from-gray-50 to-white">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h2 className="kosi-section-title">Frequently Asked Questions</h2>
          <p className="kosi-section-subtitle">
            Everything you need to know about working with Kosi Digital
          </p>
        </div>

        {/* FAQ Grid */}
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq) => (
            <div
              key={faq.id}
              className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
            >
              <button
                onClick={() => toggleFAQ(faq.id)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-left font-semibold text-foreground pr-4">
                  {faq.question}
                </h3>
                <ChevronDown
                  size={20}
                  className={`text-cyan-600 flex-shrink-0 transition-transform duration-300 ${
                    openId === faq.id ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Answer */}
              {openId === faq.id && (
                <div className="px-6 py-4 bg-gradient-to-b from-cyan-50/50 to-white border-t border-gray-200">
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-6">
            Still have questions? We're here to help.
          </p>
          <a
            href="#contact"
            className="kosi-button-primary inline-block"
          >
            Book a Free Consultation
          </a>
        </div>
      </div>
    </section>
  );
}
