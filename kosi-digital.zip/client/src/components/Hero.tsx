import { ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-white via-blue-50 to-white py-20 md:py-32">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-200 rounded-full blur-3xl opacity-20"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-200 rounded-full blur-3xl opacity-20"></div>
      </div>

      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-100 rounded-full mb-6">
            <span className="w-2 h-2 bg-cyan-500 rounded-full"></span>
            <span className="text-sm font-medium text-cyan-700">Trusted by 500+ Real Estate Agents</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
            Stop Wasting Ad Budget.
            <br />
            <span className="bg-gradient-to-r from-cyan-500 to-cyan-600 bg-clip-text text-transparent">
              Start Converting Leads.
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            Data-driven ad creatives and management built specifically for real estate agents who want results, not excuses.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <a
              href="#contact"
              className="kosi-button-primary flex items-center gap-2"
            >
              Book a Free Consultation
              <ArrowRight size={18} />
            </a>
            <a
              href="#pricing"
              className="kosi-button-secondary"
            >
              See Pricing
            </a>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-6 md:gap-8 pt-8 border-t border-gray-200">
            <div>
              <div className="text-3xl md:text-4xl font-bold text-cyan-600">3.2M+</div>
              <p className="text-sm text-muted-foreground mt-2">Leads Generated</p>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-cyan-600">42%</div>
              <p className="text-sm text-muted-foreground mt-2">Avg. Cost Reduction</p>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-cyan-600">98%</div>
              <p className="text-sm text-muted-foreground mt-2">Client Retention</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
