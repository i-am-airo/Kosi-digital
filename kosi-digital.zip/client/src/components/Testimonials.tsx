import { Star } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Sarah Mitchell",
    title: "Real Estate Agent, Miami",
    company: "Luxury Homes Realty",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
    quote: "Kosi Digital transformed how I run ads. In just 60 days, I generated 150+ qualified leads and closed 3 deals worth $2.1M. Their creative strategy is unmatched.",
    result: "150+ qualified leads in 60 days",
    rating: 5,
  },
  {
    id: 2,
    name: "Marcus Johnson",
    title: "Team Lead, Austin",
    company: "Austin Properties Group",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    quote: "We were spending $8K/month on ads with mediocre results. Kosi Digital cut our cost per lead by 42% while doubling our lead quality. Best decision we made this year.",
    result: "42% cost reduction, 2x lead quality",
    rating: 5,
  },
  {
    id: 3,
    name: "Jessica Chen",
    title: "Brokerage Owner, Los Angeles",
    company: "West Coast Elite Realty",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    quote: "Managing ads for 12 agents was a nightmare until we partnered with Kosi Digital. Their Premium package handles everything. My agents love the quality of leads.",
    result: "12 agents, 98% retention rate",
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 md:py-32 bg-white">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h2 className="kosi-section-title">Real Results from Real Agents</h2>
          <p className="kosi-section-subtitle">
            See how real estate professionals are transforming their lead generation with Kosi Digital
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-lg p-8 shadow-sm hover:shadow-md transition-shadow"
            >
              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className="fill-cyan-500 text-cyan-500"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-foreground leading-relaxed mb-6 italic">
                "{testimonial.quote}"
              </p>

              {/* Result Highlight */}
              <div className="bg-cyan-50 border-l-4 border-cyan-500 px-4 py-3 rounded mb-6">
                <p className="text-sm font-semibold text-cyan-900">
                  {testimonial.result}
                </p>
              </div>

              {/* Author */}
              <div className="flex items-center gap-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <p className="font-semibold text-foreground">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto mt-16 pt-16 border-t border-gray-200">
          <div className="text-center">
            <div className="text-4xl font-bold text-cyan-600 mb-2">500+</div>
            <p className="text-muted-foreground">Agents Trust Us</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-cyan-600 mb-2">98%</div>
            <p className="text-muted-foreground">Client Retention</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-cyan-600 mb-2">$2.1B+</div>
            <p className="text-muted-foreground">In Closed Deals</p>
          </div>
        </div>
      </div>
    </section>
  );
}
