import { Palette, Video, Settings, Globe, Brain } from "lucide-react";

const services = [
  {
    id: 1,
    title: "Ad Creatives",
    description: "Custom, high-converting static and carousel ads designed to stop scrolls and drive clicks.",
    icon: Palette,
  },
  {
    id: 2,
    title: "Video Editing",
    description: "Professional video ads that showcase properties and tell compelling stories. 15-60 second formats optimized for Meta platforms.",
    icon: Video,
  },
  {
    id: 3,
    title: "Ad Management",
    description: "Expert campaign setup, optimization, and monitoring. We handle Meta Ads so you can focus on closing deals.",
    icon: Settings,
  },
  {
    id: 4,
    title: "Landing Page Setup",
    description: "High-converting landing pages built to capture leads and reduce friction in your sales funnel.",
    icon: Globe,
  },
  {
    id: 5,
    title: "AI Automation",
    description: "Intelligent follow-up sequences, lead scoring, and CRM integration to nurture prospects automatically.",
    icon: Brain,
  },
];

export default function Services() {
  return (
    <section id="services" className="py-20 md:py-32 bg-white">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h2 className="kosi-section-title">Everything You Need to Scale</h2>
          <p className="kosi-section-subtitle">
            Comprehensive services designed to maximize your real estate marketing ROI
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="kosi-card group"
              >
                <div className="mb-4 p-3 bg-cyan-100 rounded-lg w-fit group-hover:bg-cyan-200 transition-colors">
                  <Icon className="text-cyan-600" size={24} />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  {service.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
